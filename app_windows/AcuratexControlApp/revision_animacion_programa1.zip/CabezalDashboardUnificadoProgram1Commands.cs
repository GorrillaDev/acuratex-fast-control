namespace AcuratexControlApp.Components;

public static class CabezalDashboardUnificadoProgram1Commands
{
    public static readonly CabezalDashboardUnificadoProgramProfile Profile = new(
        CabezalDashboardUnificadoProgramId.Program1,
        "Programa 1",
        CabezalDashboardUnificadoProtocol.CreateDenMotors,
        () => Array.Empty<CabezalMotorUnificado>(),
        () => Array.Empty<CabezalMotorUnificado>(),
        CreateJGroups,
        CabezalDashboardUnificadoProtocol.CreateYarnBlocks,
        CreateStitchBlocks,
        CabezalDashboardUnificadoProtocol.DenRunSequence,
        CabezalDashboardUnificadoProtocol.DenRun1Sequence,
        CabezalDashboardUnificadoProtocol.SicRunSequence,
        Array.Empty<int>(),
        CabezalDashboardUnificadoProtocol.SicRunPeriodMs,
        CabezalDashboardUnificadoProtocol.SicRunPeriodMs);

    private static IReadOnlyList<CabezalJGroupUnificado> CreateJGroups() =>
        Enumerable.Range(1, 8)
            .Select(number => new CabezalJGroupUnificado(number, number, visiblePinCount: 6))
            .ToArray();

    private static IReadOnlyList<CabezalOutputBlockUnificado> CreateStitchBlocks() =>
        CabezalDashboardUnificadoProtocol.CreateStitchBlocks()
            .Select(block =>
            {
                block.VisiblePositionCount = 5;
                return block;
            })
            .ToArray();
}